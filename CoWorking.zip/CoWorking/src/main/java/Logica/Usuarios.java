
package Logica;

import java.util.ArrayList;
import java.util.List;

//Creacion de variables, contructores, getters y setters
public class Usuarios {
    private String Usuario;
    private String fecha;
    private String tipo;
    private int duracion;
List<Usuarios>ListaUsuarios= new ArrayList<>();
    public Usuarios() {
    }

    public Usuarios(String Usuario, String fecha, String tipo, int duracion) {
        this.Usuario = Usuario;
        this.fecha = fecha;
        this.tipo = tipo;
        this.duracion = duracion;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }


}
