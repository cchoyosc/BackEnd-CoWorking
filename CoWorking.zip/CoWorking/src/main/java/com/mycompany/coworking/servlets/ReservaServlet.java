/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.coworking.servlets;

import Logica.Usuarios;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "ReservaServlet", urlPatterns = {"/ReservaServlet"})
public class ReservaServlet extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
      
        
    }

 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        //Se optiene los valores que conlleva cada variable
        
        String usuario=request.getParameter("usuario");
        String fecha=request.getParameter("fecha");
        String tipo= request.getParameter("tipo");
        int duracion= Integer.parseInt(request.getParameter("duracion")) ;
         ServletContext context = getServletContext();
         
        ArrayList<Usuarios> ListaUsuarios = (ArrayList<Usuarios>) context.getAttribute("ListaUsuarios");
        //Se coloca un condicional en caso tal de no existir una lista entonces que se cree
        if (ListaUsuarios == null) {
            ListaUsuarios = new ArrayList<>();
        }
        Usuarios usu = new Usuarios(usuario,fecha,tipo,duracion);
           
          ListaUsuarios.add(usu);
          
         // Guardar la lista actualizada en el contexto de la aplicación
         
        context.setAttribute("ListaUsuarios", ListaUsuarios);
        
        //Redirige de nuevo a ListasReservasServlet si se requiere realizar otrar eliminacion de registro
        response.sendRedirect("ListasReservasServlet");
        
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
